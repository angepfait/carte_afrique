import React from "react";
import MyMap from "./components/MyMap";

function App() {
  return <MyMap />;
}

export default App; 
